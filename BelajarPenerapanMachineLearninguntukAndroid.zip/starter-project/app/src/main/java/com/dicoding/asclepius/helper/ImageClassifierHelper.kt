package com.dicoding.asclepius.helper

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import com.dicoding.asclepius.view.ResultActivity
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

class ImageClassifierHelper(private val context: Context) {

    private var interpreter: Interpreter? = null

    init {
        setupImageClassifier()
    }

    private fun setupImageClassifier() {
        try {
            val modelFile = loadModelFile()
            interpreter = Interpreter(modelFile)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadModelFile(): ByteBuffer {
        val fileDescriptor = context.assets.openFd("cancer_classification.tflite")
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    fun classifyStaticImage(imageUri: Uri) {
        try {

            val bitmap = uriToBitmap(imageUri)

            val inputBuffer = preprocessImage(bitmap)


            val result = Array(1) { FloatArray(2) }
            interpreter?.run(inputBuffer, result)


            val confidenceCancer = result[0][1]
            val confidenceNonCancer = result[0][0]

            val isCancer = confidenceCancer > 0.5
            val resultText = if (isCancer) {
                "Prediksi: Kanker dengan skor kepercayaan ${"%.2f".format(confidenceCancer * 100)}%"
            } else {
                "Prediksi: Tidak Kanker dengan skor kepercayaan ${"%.2f".format(confidenceNonCancer * 100)}%"
            }


            val intent = Intent(context, ResultActivity::class.java).apply {
                putExtra("RESULT_TEXT", resultText)
                putExtra("IMAGE_URI", imageUri.toString())
            }
            context.startActivity(intent)

        } catch (e: Exception) {
            e.printStackTrace()
            val errorText = "Gagal memproses gambar: ${e.message}"


            val intent = Intent(context, ResultActivity::class.java).apply {
                putExtra("RESULT_TEXT", errorText)
                putExtra("IMAGE_URI", imageUri.toString())
            }
            context.startActivity(intent)
        }
    }

    private fun uriToBitmap(uri: Uri): Bitmap {
        val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.isMutableRequired = true
            }
        } else {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            BitmapFactory.decodeStream(inputStream) ?: throw IllegalArgumentException("Failed to decode image")
        }


        return bitmap.copy(Bitmap.Config.ARGB_8888, true)
    }

    private fun preprocessImage(bitmap: Bitmap): ByteBuffer {
        val inputSize = 224
        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)
        val inputBuffer = ByteBuffer.allocateDirect(4 * inputSize * inputSize * 3)
        inputBuffer.order(ByteOrder.nativeOrder())

        for (y in 0 until inputSize) {
            for (x in 0 until inputSize) {
                val pixelValue = scaledBitmap.getPixel(x, y)


                inputBuffer.putFloat(((pixelValue shr 16 and 0xFF) - 127) / 128f)
                inputBuffer.putFloat(((pixelValue shr 8 and 0xFF) - 127) / 128f)
                inputBuffer.putFloat(((pixelValue and 0xFF) - 127) / 128f)
            }
        }
        return inputBuffer
    }
}
