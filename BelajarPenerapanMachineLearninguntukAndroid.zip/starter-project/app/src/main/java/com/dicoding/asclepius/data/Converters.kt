package com.dicoding.asclepius.data

import android.net.Uri
import androidx.room.TypeConverter
import android.util.Log

class Converters {
    @TypeConverter
    fun fromUri(uri: Uri?): String? {
        return uri?.toString()
    }

    @TypeConverter
    fun toUri(uriString: String?): Uri? {
        return try {
            uriString?.let { Uri.parse(it) }
        } catch (e: Exception) {
            Log.e("Converters", "Error converting String to Uri: ${e.message}")
            null
        }
    }
}
