package com.dicoding.asclepius.utils

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object ImageUtils {

    fun saveImageToInternalStorage(context: Context, image: Bitmap, fileName: String): String? {
        val file = File(context.filesDir, fileName)
        return try {
            val outputStream = FileOutputStream(file)
            image.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
            outputStream.flush()
            outputStream.close()

            if (file.exists()) {
                Log.d("ImageUtils", "Image successfully saved at path: ${file.absolutePath}")
                file.absolutePath
            } else {
                Log.e("ImageUtils", "Failed to save image, file does not exist.")
                null
            }
        } catch (e: IOException) {
            e.printStackTrace()
            Log.e("ImageUtils", "Error saving image: ${e.message}")
            null
        }
    }
}
