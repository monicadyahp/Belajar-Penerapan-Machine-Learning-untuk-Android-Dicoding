package com.dicoding.asclepius.view

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dicoding.asclepius.data.AppDatabase
import com.dicoding.asclepius.data.PredictionHistory
import com.dicoding.asclepius.databinding.ActivityResultBinding
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

class ResultActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultBinding
    private val predictionHistoryDao by lazy {
        AppDatabase.getDatabase(this).predictionHistoryDao()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val resultText = intent.getStringExtra("RESULT_TEXT") ?: "Tidak ada hasil"
        val imageUri = intent.getStringExtra("IMAGE_URI")?.let { Uri.parse(it) }
        val confidenceScore = intent.getFloatExtra("CONFIDENCE_SCORE", 0f)

        // Display result text and image
        binding.resultText.text = resultText
        imageUri?.let {
            binding.resultImage.setImageURI(it)
        }

        binding.saveButton.setOnClickListener {
            imageUri?.let {
                val bitmap = BitmapFactory.decodeStream(contentResolver.openInputStream(it))
                val byteArrayOutputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
                val imageData = byteArrayOutputStream.toByteArray()

                val history = PredictionHistory(
                    imageData = imageData,
                    resultText = resultText,
                    confidenceScore = confidenceScore,
                    timestamp = System.currentTimeMillis()
                )
                savePredictionHistory(history)
            }
        }
    }

    private fun savePredictionHistory(history: PredictionHistory) {
        lifecycleScope.launch {
            predictionHistoryDao.insert(history)
            Toast.makeText(this@ResultActivity, "Riwayat disimpan", Toast.LENGTH_SHORT).show()
        }
    }
}
