package com.dicoding.asclepius.data

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.launch

class PredictionHistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PredictionHistoryRepository
    val allHistory: LiveData<List<PredictionHistory>>

    init {
        val dao = AppDatabase.getDatabase(application).predictionHistoryDao()
        repository = PredictionHistoryRepository(dao)
        allHistory = repository.allHistory
    }

    fun insert(history: PredictionHistory) = viewModelScope.launch {
        repository.insert(history)
    }

    fun insertWithImage(image: Bitmap, resultText: String, confidenceScore: Float) = viewModelScope.launch {

        val byteArrayOutputStream = ByteArrayOutputStream()
        image.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
        val imageData = byteArrayOutputStream.toByteArray()

        val predictionHistory = PredictionHistory(
            imageData = imageData,
            resultText = resultText,
            confidenceScore = confidenceScore
        )
        repository.insert(predictionHistory)
    }

    fun delete(history: PredictionHistory) = viewModelScope.launch {
        repository.delete(history)
    }
}
