package com.dicoding.asclepius.data

import androidx.lifecycle.LiveData

class PredictionHistoryRepository(private val dao: PredictionHistoryDao) {
    val allHistory: LiveData<List<PredictionHistory>> = dao.getAllHistory()

    suspend fun insert(history: PredictionHistory) {
        dao.insert(history)
    }

    suspend fun delete(history: PredictionHistory) {
        dao.delete(history)
    }
}
