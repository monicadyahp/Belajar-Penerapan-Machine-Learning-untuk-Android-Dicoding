package com.dicoding.asclepius.view

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.asclepius.data.PredictionHistoryViewModel
import com.dicoding.asclepius.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryBinding
    private val viewModel: PredictionHistoryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel.allHistory.observe(this, Observer { historyList ->
            try {
                if (historyList != null && historyList.isNotEmpty()) {
                    Log.d("HistoryActivity", "History list loaded with ${historyList.size} items.")
                    binding.recyclerView.adapter = HistoryAdapter(historyList)
                } else {
                    Log.d("HistoryActivity", "History list is empty or null.")
                    binding.recyclerView.adapter = HistoryAdapter(emptyList())
                }
            } catch (e: Exception) {
                Log.e("HistoryActivity", "Error loading history: ${e.message}")
            }
        })
    }
}
